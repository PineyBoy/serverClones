import os, sys, time, random

def mainCode():
    nameList = ["gay", "an idiot", "a hoe", "a moron", "a pest", "stupid"]
    print("Kay is " + random.choice(nameList))

mainCode()