import os, sys, time, random
import discord

TOKEN = "OTQ0MDE5MDM2ODA5ODcxNDEw.Yg7gPQ.kYSpADJhVS6dpPcejUaeqhSqX1g"
client = discord.Client()
bussyList = ["3.jpg", "2.png", "1.jpg", "4.jpg"]

@client.event
async def on_ready():
    print('We have logged in as {0.user}'.format(client))

@client.event
async def on_message(message):
    if message.author == client.user:
        return

    if message.content.startswith("b!hai"):
        await message.channel.send("Hai!")

    if 'femboy' in message.content:
        chosen = random.choice(bussyList)
        os.chdir("/home/anarchypineapple/Desktop/Coding/Python/THYBUSSY")
        await message.channel.send(file = discord.File(chosen))
    
    if 'Femboy' in message.content:
        await message.channel.send("No.")

    if 'FEMBOY' in message.content:
        await message.channel.send("No.")

client.run(TOKEN)