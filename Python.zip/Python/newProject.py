import os, sys, time, random

def mainCode():
    print("helloWorld")

mainCode()