// Getting The Moduels
const express = require("express");
const socket = require("socket.io");

// App setup
const PORT = 6060; // define the port that the server will be on
const app = express(); // Make the app using express!

const server = app.listen(PORT, function () { // Listen using the port we supplied
  console.log(`Listening on port ${PORT}`);  // log the port we're using
  console.log(`http://localhost:${PORT}`); // log the full adress we're using port included
});

// Socket setup
const io = socket(server); // link socket.io to the server

// Static files
app.use(express.static("/home/anarchypineapple/Desktop/Coding/NodeJS/rotateBanana/public")); // locate the static files (public folder) and include them

app.get('/', (req, res) => { // If we go to http://localhost:6060/ then: (request)
    res.sendFile("/home/anarchypineapple/Desktop/Coding/NodeJS/rotateBanana/index.html"); // Send the html file we have supplied (response)
});

io.on('connection', function(socket) { // On connection made:
  console.log('A user connected'); // When someone connects log
  
  socket.on('disconnect', function () { // On connection broken:
     console.log('A user disconnected'); // Log that someone has dicconected
  });

  socket.on('msg', (msg) => { // When we recieve a message:
      console.log('message: ' + msg); // Log the message that the user has sent
      io.emit('msg', msg) // Emit the message globaly over all clients back to the front end
    });
});